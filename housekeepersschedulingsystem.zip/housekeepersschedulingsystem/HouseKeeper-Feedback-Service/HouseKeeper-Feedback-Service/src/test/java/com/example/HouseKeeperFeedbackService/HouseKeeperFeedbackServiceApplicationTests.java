package com.example.HouseKeeperFeedbackService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HouseKeeperFeedbackServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
