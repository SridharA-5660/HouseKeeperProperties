package com.example.Entity;

public class Feedback {
	
	private long feedback_id;

	private String feedback;
	
	public long getFeedback_id() {
		return feedback_id;
	}
	public void setFeedback_id(long feedback_id) {
		this.feedback_id = feedback_id;
	}
	
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public Feedback(long feedback_id, String feedback) {
		super();
		this.feedback_id = feedback_id;
		this.feedback = feedback;
	}
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}


