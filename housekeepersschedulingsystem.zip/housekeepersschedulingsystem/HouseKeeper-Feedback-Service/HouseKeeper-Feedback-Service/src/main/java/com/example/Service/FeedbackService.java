package com.example.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Entity.Feedback;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("housekeeper-service")
public interface FeedbackService {
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackSubmitFeedback")
	@PostMapping("/submitFeedback/{request_id}")
	public Feedback submitFeedback(@RequestBody Feedback feedback,@PathVariable("request_id") int requestId) ;
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackGetFeedbackCount")
	@GetMapping("/getFeedbackCount/{hostel}")
	public Integer getFeedbackCount(@PathVariable("hostel") String hostel) ;
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackGetFeedbackCountByRollnumber")
	@GetMapping("/getFeedbackCountByRollnumber/{rollnumber}")
	public Integer getFeedbackCountByRollnumber(@PathVariable("rollnumber") long rollnumber) ;
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackGetAllFeedbackByHostel")
	@GetMapping("/getAllFeedbackByHostel/{hostel}")
	public List<Feedback> getAllFeedbackByHostel(@PathVariable("hostel") String hostel);
	
	default Feedback fallbackSubmitFeedback(@RequestBody Feedback feedback,@PathVariable("request_id") int requestId,Throwable cause) {
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new Feedback(1,"Feedback Fallback");
	}
	
	default Integer fallbackGetFeedbackCount(@PathVariable("hostel") String hostel,Throwable cause) {
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return 0;
	}
	
	default Integer fallbackGetFeedbackCountByRollnumber(@PathVariable("rollnumber") long rollnumber,Throwable cause) {
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return 0;
	}
	
	default List<Feedback> fallbackGetAllFeedbackByHostel(@PathVariable("hostel") String hostel,Throwable cause){
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new ArrayList<Feedback>();
	}
	
	
	
	
}
