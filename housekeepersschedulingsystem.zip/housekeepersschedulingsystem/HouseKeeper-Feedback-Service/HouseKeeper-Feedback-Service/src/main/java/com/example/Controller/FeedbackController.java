package com.example.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Feedback;
import com.example.Service.FeedbackService;

@RestController
@Scope("request")
public class FeedbackController {
	@Autowired
	private FeedbackService feedbackService;
	
	private Logger log=LoggerFactory.getLogger(FeedbackController.class);
			
	@GetMapping("/feedback/getFeedbackCount/{hostel}")
	public Integer getFeedbackCount(@PathVariable("hostel") String hostel) {
		log.debug("In getfeedbackCount");
		Integer integer=feedbackService.getFeedbackCount(hostel);
				return integer;
	}
	
	@GetMapping("/feedback/getFeedbackCountByRollnumber/{rollnumber}")
	public Integer getFeedbackCountByRollnumber(@PathVariable("rollnumber") long rollnumber) {
		log.debug("In getFeedbackCountByRollnumber");
		Integer integer= feedbackService.getFeedbackCountByRollnumber(rollnumber);
		return integer;
	}
	
	@GetMapping("/feedback/getAllFeedbackByHostel/{hostel}")
	public List<Feedback> getAllFeedbackByHostel(@PathVariable("hostel") String hostel){
		log.debug("In getAllFeedbackByHostel");
		List<Feedback> list =feedbackService.getAllFeedbackByHostel(hostel);
		return list;
	}
	
	@PostMapping("/feedback/submitFeedback/{request_id}")
	public Feedback submitFeedback(@RequestBody Feedback feedback, @PathVariable("request_id") int requestId) {
		log.debug("In submitFeedback");
	    Feedback submittedFeedback = feedbackService.submitFeedback(feedback, requestId);
	    return submittedFeedback;
	}


}
