package com.example.Service;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Entity.CleanRequest;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("housekeeper-service")
public interface CleanRequestService {

	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodsubmitRequest")
	@PostMapping("/submitRequest/{rollno}")
	public CleanRequest submitRequest(@PathVariable("rollno") long rollno,@RequestBody CleanRequest cleanRequest);
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodgetRequestCount")
	@GetMapping("/requestCount/{rollno}")
	public List<Integer> getRequestCount(@PathVariable("rollno") long rollno);
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodgetCleanRequestByRollnumber")
	@GetMapping("/getCleanRequestByRollnumber/{rollno}")
	public List<CleanRequest> getCleanRequestByRollnumber(@PathVariable("rollno") long rollno) ;
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodgetAllCleanRequest")
	@GetMapping("/getAllCleanRequestByHostel/{hostel}")
	public List<CleanRequest> getAllCleanRequest(@PathVariable("hostel") String hostel) ;
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodgetAllCleanRequestCount")
	@GetMapping("/getAllCleanRequestCountByHostel/{hostel}")
	public Integer getAllCleanRequestCount(@PathVariable("hostel") String hostel) ; 
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodgetCleanRequestById")
	@GetMapping("/getRequestById/{id}")
	public CleanRequest getCleanRequestById(@PathVariable("id") int id);  
	
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodallotHouseKeeper")
	@GetMapping("/allotHouseKeeper/{cleanRequestId}/{workerId}")
	public CleanRequest allotHouseKeeper(@PathVariable("cleanRequestId") int cleanRequestId,@PathVariable("workerId") int workerId); 
	
	
	
	public default CleanRequest fallbackMethodsubmitRequest(@PathVariable("rollno") long rollno,@RequestBody CleanRequest cleanRequest, Throwable cause) {
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new CleanRequest(1,new Date(), LocalTime.of(9, 30), true, true);
	}
	
	public default List<Integer> fallbackMethodgetRequestCount(@PathVariable("rollno") long rollno, Throwable cause){
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return null;
	}
	public default List<CleanRequest> fallbackMethodgetCleanRequestByRollnumber(@PathVariable("rollno") long rollno, Throwable cause){
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new ArrayList<CleanRequest>();
	}
	public default List<CleanRequest> fallbackMethodgetAllCleanRequest(@PathVariable("hostel") String hostel, Throwable cause){
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new ArrayList<CleanRequest>();
	}
	
	public default Integer fallbackMethodgetAllCleanRequestCount(@PathVariable("hostel") String hostel,Throwable cause ) {
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return 0; 
	}
	public default CleanRequest fallbackMethodgetCleanRequestById(@PathVariable("id") int id,Throwable cause ) {
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new CleanRequest(1, new Date(), LocalTime.of(9, 30), true, true);
	}
	public default CleanRequest fallbackMethodallotHouseKeeper(@PathVariable("cleanRequestId") int cleanRequestId,@PathVariable("workerId") int workerId,Throwable cause ) {
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new CleanRequest(1,new Date(), LocalTime.of(9, 30), true, true);
	}
	
	
}