package com.example.Entity;


import java.time.LocalTime;
import java.util.Date;


public class CleanRequest {

	
	private int request_id;
	private Date date;	
	private LocalTime cleanTime;
	private boolean feedback_status;
	private boolean req_status;
	
	public boolean isFeedback_status() {
		return feedback_status;
	}

	public void setFeedback_status(boolean feedback_status) {
		this.feedback_status = feedback_status;
	}

	public long getRequest_id() {
		return request_id;
	}

	public void setRequest_id(int request_id) {
		this.request_id = request_id;
	}



	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public LocalTime getCleanTime() {
		return cleanTime;
	}

	public void setCleanTime(LocalTime cleanTime) {
		this.cleanTime = cleanTime;
	}

	public boolean isReq_status() {
		return req_status;
	}

	public void setReq_status(boolean req_status) {
		this.req_status = req_status;
	}

	public CleanRequest(int request_id, Date date, LocalTime cleanTime, boolean feedback_status, boolean req_status) {
		super();
		this.request_id = request_id;
		this.date = date;
		this.cleanTime = cleanTime;
		this.feedback_status = feedback_status;
		this.req_status = req_status;
	}

	public CleanRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
