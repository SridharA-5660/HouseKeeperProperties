package com.example.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.CleanRequest;
import com.example.Service.CleanRequestService;

@RestController
@Scope("request")
public class CleanRequestController {

	@Autowired
	private CleanRequestService cleanRequestService;
	
	private Logger log=LoggerFactory.getLogger(CleanRequestController.class);
	
	@PostMapping("/submitRequest/{rollno}")
	public CleanRequest submitRequest(@PathVariable("rollno") long rollno,@RequestBody CleanRequest cleanRequest) {
		log.debug("In submitRequest");
		CleanRequest cleanRequest1 = cleanRequestService.submitRequest(rollno, cleanRequest);
		return cleanRequest1;
	
	}
	
	@GetMapping("/requestCount/{rollno}")
	public List<Integer> getRequestCount(@PathVariable("rollno") long rollno){
		log.debug("In getrequestCount");
		List<Integer> cleanRequest1 = cleanRequestService.getRequestCount(rollno);
		return cleanRequest1;
	}
	
	@GetMapping("/getCleanRequestByRollnumber/{rollno}")
	public List<CleanRequest> getCleanRequestByRollnumber(@PathVariable("rollno") long rollno){
		log.debug("in getCleanRequestByRollnumber");
		List<CleanRequest> cleanRequest1 = cleanRequestService.getCleanRequestByRollnumber(rollno);
		return cleanRequest1;
	}
	
	@GetMapping("/getAllCleanRequestByHostel/{hostel}")
	public List<CleanRequest> getAllCleanRequest(@PathVariable("hostel") String hostel){
		log.debug("In getAllCleanRequest");
		List<CleanRequest> cleanRequest1 = cleanRequestService.getAllCleanRequest(hostel);
		return cleanRequest1;
	}
	
	@GetMapping("/getAllCleanRequestCountByHostel/{hostel}")
	public Integer getAllCleanRequestCount(@PathVariable("hostel") String hostel) {
		log.debug("In getAllCleanRequestCount");
		Integer integer = cleanRequestService.getAllCleanRequestCount(hostel);
		return integer;
	}
	
	@GetMapping("/getRequestById/{id}")
	public CleanRequest getCleanRequestById(@PathVariable("id") int id) {
		log.debug("In getCleanRequestById");
		CleanRequest cleanRequest1 = cleanRequestService.getCleanRequestById(id);
		return cleanRequest1;
	}
	
	
	@GetMapping("/allotHouseKeeper/{cleanRequestId}/{workerId}")
	public CleanRequest allotHouseKeeper(@PathVariable("cleanRequestId") int cleanRequestId,@PathVariable("workerId") int workerId) {
		log.debug("In allotHouseKeeper");
		CleanRequest cleanRequest1= cleanRequestService.allotHouseKeeper(cleanRequestId, workerId);
		return cleanRequest1;
		
	}
}