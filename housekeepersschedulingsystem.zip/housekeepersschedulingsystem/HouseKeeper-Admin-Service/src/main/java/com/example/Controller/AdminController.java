package com.example.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Admin;
import com.example.Service.AdminService;

@RestController
@Scope("request")
public class AdminController {

	@Autowired
	private AdminService adminService;
	
	private Logger log=LoggerFactory.getLogger(AdminController.class);
	
	@GetMapping("/admin/getAdmin")
	public List<Admin> getAdmin(){
		log.debug("In getAdmin:");
		List<Admin> admins=adminService.getAdmin();
		log.debug("List<Admin> values:"+admins);
		return admins;
	}
	
	@PostMapping("/admin/saveAdmin")
	public Admin saveAdmin(@RequestBody Admin admin) {
		log.debug("In saveAdmin:");
		Admin saveadmin=adminService.saveAdmin(admin);
		log.debug("saved Admin value:"+saveadmin);
		return saveadmin;
		
	}
	
	@PostMapping("/admin/checkAdminLogin")
	public ResponseEntity<Admin> checkAdmin(@RequestBody Admin admin){
		log.debug("In check Admin:");
		ResponseEntity<Admin> admincheck=adminService.checkAdmin(admin);
		log.debug("check Admin value:"+admincheck);
		return admincheck;
		
	}
	
	@GetMapping("/admin/getAdminById/{adminId}")
	public Admin getAdminById(@PathVariable("adminId") int id) {
		log.debug("In getAdminById id:"+id);
		Admin admin=adminService.getAdminById(id);
		log.debug("getAdminById values:"+admin);
		return admin;
		
	}
}
