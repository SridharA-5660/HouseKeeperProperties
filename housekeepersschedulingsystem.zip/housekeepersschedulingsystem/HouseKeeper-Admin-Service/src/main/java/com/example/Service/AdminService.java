package com.example.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Entity.Admin;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("housekeeper-service")
public interface AdminService {
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodGetAdmin")
	@GetMapping("/getAdmin")
	public List<Admin> getAdmin();
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodSaveAdmin")
	@PostMapping("/saveAdmin")
	public Admin saveAdmin(@RequestBody Admin admin);
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodCheckAdmin")
	@PostMapping("/checkAdminLogin")
	public ResponseEntity<Admin> checkAdmin(@RequestBody Admin admin);
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodGetAdminById")
	@GetMapping("/getAdminById/{adminId}")
	public Admin getAdminById(@PathVariable("adminId") int id);
	
	
	default List<Admin> fallbackMethodGetAdmin(Throwable cause){
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new ArrayList<Admin>();
		
	}
	
	default Admin fallbackMethodSaveAdmin(@RequestBody Admin admin,Throwable cause) {
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new Admin(1,"Error","Fallback method","Hostel");

	}
	
	default ResponseEntity<Admin> fallbackMethodCheckAdmin(@RequestBody Admin admin,Throwable cause){
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return null;
		
	}
	
	default Admin fallbackMethodGetAdminById(@PathVariable("adminId") int id,Throwable cause) {
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new Admin(1,"Error","Fallback method","Hostel");


	}
	

}
