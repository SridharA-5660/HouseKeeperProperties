package com.example.Entity;
	
	public class Student {
		private long rollnumber;
		private String password;
		private int floor;
		private String hostel;
		private String room;
	
	
	
	
	
	
	public long getRollnumber() {
		return rollnumber;
	}




	public void setRollnumber(long rollnumber) {
		this.rollnumber = rollnumber;
	}




	public String getPassword() {
		return password;
	}




	public void setPassword(String password) {
		this.password = password;
	}




	public int getFloor() {
		return floor;
	}




	public void setFloor(int floor) {
		this.floor = floor;
	}




	public String getHostel() {
		return hostel;
	}




	public void setHostel(String hostel) {
		this.hostel = hostel;
	}




	public String getRoom() {
		return room;
	}




	public void setRoom(String room) {
		this.room = room;
	}




	public Student(long rollnumber, String password, int floor, String hostel, String room) {
		super();
		this.rollnumber = rollnumber;
		this.password = password;
		this.floor = floor;
		this.hostel = hostel;
		this.room = room;
	}
	public Student() {
		super();
		
	}
	

}
