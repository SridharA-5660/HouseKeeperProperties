package com.example.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Entity.Student;
import com.example.dto.PasswordChange;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("housekeeper-service")
public interface StudentService {

	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodSaveStudent")
	@PostMapping("/saveStudent/{hostel}")
	public Student saveStudent(@RequestBody Student student,@PathVariable("hostel") String hostel);
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodGetStudent")
	@GetMapping("/getStudent/{rollno}")
	public Student getStudent(@PathVariable("rollno") long rollnumber) ;
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodGetAllStudent")
	@GetMapping("/getAllStudent")
	public List<Student> getAllStudent();
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodCheckUserLogin")
	@PostMapping("/checkUserLogin")
	public ResponseEntity<Student> checkStudent(@RequestBody Student student);
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodUpdateStudentProfile")
	@PutMapping("/updateStudentProfile/{rollnumber}")
	public ResponseEntity<Student> updateStudentProfile(@PathVariable("rollnumber") long rollnumber, @RequestBody Student updatedStudent) ;
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackMethodChangePasswordOfStudent")
	@PutMapping("/changePasswordOfStudent/{rollnumber}")
	public ResponseEntity<Student> changePasswordOfStudent(@RequestBody PasswordChange student,@PathVariable("rollnumber") long rollnumber);
	
	default Student fallbackMethodSaveStudent(@RequestBody Student student,@PathVariable("hostel") String hostel,Throwable cause) {
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new Student(1,"Fallback method",0,"Hostel","Room");
	}
	
	default Student fallbackMethodGetStudent(@PathVariable("rollno") long rollno,Throwable cause) {
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new Student(1,"Fallback method",0,"Hostel","Room");

	}
	
	default List<Student> fallbackMethodGetAllStudent(Throwable cause){
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new ArrayList<Student>();
		
	}
	
	default ResponseEntity<Student> fallbackMethodCheckUserLogin(@RequestBody Student student,Throwable cause){
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return null;
		
	}
	

	default ResponseEntity<Student> fallbackMethodUpdateStudentProfile(@PathVariable("rollnumber") long rollnumber,@RequestBody Student updatedstudent,Throwable cause){
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return null;
		
	}
	
	default ResponseEntity<Student> fallbackMethodChangePasswordOfStudent(@RequestBody PasswordChange student,@PathVariable("rollnumber") long rollnumber,Throwable cause){
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return null;
		
	}
	
}
