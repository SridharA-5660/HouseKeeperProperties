package com.example.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Student;
import com.example.Service.StudentService;
import com.example.dto.PasswordChange;

@RestController
@Scope("request")
public class StudentController {

	@Autowired
	private StudentService studentService;
	
	private Logger log=LoggerFactory.getLogger(StudentController.class);
			
	@PostMapping("/saveStudent/{hostel}")
	public Student saveStudent(@RequestBody Student student,@PathVariable("hostel") String hostel) {
		log.debug("In savestudent");
		Student student1 = studentService.saveStudent(student, hostel);
		log.debug("savestudent value:"+student1);
		return student1;
	}
	
	
	@GetMapping("/getStudent/{rollno}")
	public Student getStudent(@PathVariable("rollno") long rollnumber) {
		log.debug("in getstudent");
		Student student1 = studentService.getStudent(rollnumber);
		log.debug("getStudent value"+student1);
		return student1;
	}
	
	
	@GetMapping("/getAllStudent")
	public List<Student> getAllStudent(){
		log.debug("in getAllStudent");
		List<Student> student1 = studentService.getAllStudent();
		log.debug("getAllStudent value"+student1);
		return student1;
		
	}
	
	
	@PostMapping("/checkUserLogin")
	public ResponseEntity<Student> checkStudent(@RequestBody Student student){
		log.debug("In checkStudent");
		ResponseEntity<Student> student1 = studentService.checkStudent(student);
		log.debug("checkStudent value"+student1);
		return student1;
	}
	
	
	@PutMapping("/updateStudentProfile/{rollnumber}")
	public ResponseEntity<Student> updateStudentProfile(@PathVariable("rollnumber") long rollnumber, @RequestBody Student updatedStudent) {
		log.debug("In updateStudentProfile");
		ResponseEntity<Student> student1 = studentService.updateStudentProfile(rollnumber, updatedStudent);
		log.debug("updateStudentProfile value"+student1);
		return student1;
	}
	
	
	@PutMapping("/changePasswordOfStudent/{rollnumber}")
	public ResponseEntity<Student> changePasswordOfStudent(@RequestBody PasswordChange student,@PathVariable("rollnumber") long rollnumber){
		log.debug("In changePasswordOfStudent");
		ResponseEntity<Student> student1 = studentService.changePasswordOfStudent(student, rollnumber);
		return student1;
	}
	
}
