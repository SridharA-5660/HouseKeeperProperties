package com.example.Entity;


public class Worker {

	
	private int worker_id;
	private String name;
	private int floor;
	private String hostel;
	
	public String getHostel() {
		return hostel;
	}
	public void setHostel(String hostel) {
		this.hostel = hostel;
	}
	public void setWorker_id(int worker_id) {
		this.worker_id = worker_id;
	}
	
	public long getWorker_id() {
		return worker_id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
	
	
}
