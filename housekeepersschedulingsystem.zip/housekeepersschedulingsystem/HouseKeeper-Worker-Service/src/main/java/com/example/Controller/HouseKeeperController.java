package com.example.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Worker;
import com.example.Service.WorkerService;

@RestController
@Scope("request")
public class HouseKeeperController {
	
	@Autowired
	private WorkerService workerService;
	
	private Logger log=LoggerFactory.getLogger(HouseKeeperController.class);

	@PostMapping("/registerWorker/{hostel}")
	public Worker registerWorker(@RequestBody Worker worker,@PathVariable("hostel") String hostel) {
		log.debug("In registerWorker");
		Worker workerObj= workerService.registerWorker(worker, hostel);
		return workerObj;
		
	}
	
	@GetMapping("/getHouseKeeperByFloor/{floor}/{hostel}")
	public List<Worker> getWorkerByFloor(@PathVariable("floor") int floor,@PathVariable("hostel") String hostel){
		log.debug("getWorkerByFloor");
		List<Worker> workerObj= workerService.getWorkerByFloor(floor, hostel);
		return workerObj;
	}

}
