package com.example.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Entity.Worker;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("housekeeper-service")
public interface WorkerService {
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackRegisterWorker")
	@PostMapping("/registerWorker/{hostel}")
	public Worker registerWorker(@RequestBody Worker worker,@PathVariable("hostel") String hostel);
	
	@Retry(name="housekeeper-service")
	@CircuitBreaker(name="housekeeper-service",fallbackMethod="fallbackGetWorkerByFloor")
	@GetMapping("/getHouseKeeperByFloor/{floor}/{hostel}")
	public List<Worker> getWorkerByFloor(@PathVariable("floor") int floor,@PathVariable("hostel") String hostel);
	
	
	default Worker fallbackRegisterWorker(@RequestBody Worker worker,@PathVariable("hostel") String hostel,Throwable cause) {
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new Worker();
	}
	
	default List<Worker> fallbackGetWorkerByFloor(@PathVariable("floor") int floor,@PathVariable("hostel") String hostel,Throwable cause){
		System.out.println("Exception raised with message:===>"+cause.getMessage());
		return new ArrayList<Worker>();
	}

}
